# shadcn/ui + vite + Tailwind v3

A template for a React + TypeScript + Vite + Tailwind v3 project.
