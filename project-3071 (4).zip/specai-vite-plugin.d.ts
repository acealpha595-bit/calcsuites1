declare module "specai-vite-plugin.js" {
  export const componentSpecTree: any
}
